#include<bits/stdc++.h>
using namespace std;

priority_queue< pair<int,pair<int,int>> vector<pair<int,pair<int,int>>> greater <pair<int,pair<int,int>>>>pq;
void priority(int at[],int bt[],int pri[],int &sum,int i)
{
      pq.push({pri[i],{at[i],i}});
}
void sample(int at[],int bt[],int pri[],int &sum,int n)
{
    for(int i=0;i<n;i++)
     {
        if(at[i]<=sum && bt[i]!=0)
        {
            priority(at,bt,pri,i,sum);
        }
     }
}
int main()
{
     int n;
     cout<<"n:"<<" ";
     cin>>n;
     int bt[n],at[n],pri[n];
    
     for(int i=0;i<n;i++)
     {
        cin>>at[i];
     }
      for(int i=0;i<n;i++)
     {
        cin>>bt[i];
     }
      for(int i=0;i<n;i++)
     {
        cin>>pri[i];
     }
     int min=INT_MAX,index;
     for(int i=0;i<n;i++)
     {
         if(at[i]<min)
         {
            min=at[i];
            index=i;
         }
     }
     int sum=0;
     int ct[n];
    //  ct[index]=sum+bt[index];
    //  sum+=bt[i];
     pq.push({pri[index],{at[index],index}});
     while(!pq.empty())
     {
        int it=pq.top().second.second;
        pq.pop();
        ct[it]=sum+bt[it];
        sum=sum+bt[it];
        sample(at,bt,pri,sum,n);
     }
     
     
cout<<sum<<endl;
     
}
