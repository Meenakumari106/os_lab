#include<bits/stdc++.h>
using namespace std;

int main()
{
    int tq;
    cout<<"tq:"<<" ";
    cin>>tq;
     int n;
     cout<<"enter n:"<<" ";
     cin>>n;
    int at[n],bt[n],dt[n];
    cout<<"enter at:"<<" "; 
     for(int i=0;i<n;i++)
      cin>>at[i];
    cout<<"enter bt:"<<" "; 
     for(int i=0;i<n;i++)
     {
      cin>>bt[i];
      dt[i]=bt[i]; 
     }
    int min=INT_MAX;
    int index;
    int ct[n];
    for(int i=0;i<n;i++)
    {
        if(at[i]<min)
        {
         min=at[i];
         index=i;
        }
    }
    int max=-1;
    for(int i=0;i<n;i++)
    {
        if(at[i]>max)
        {
        max=at[i];
        
        }
    }
    cout<<"min: "<<min<<" index:"<<index<<endl;
   int sum=0;
   //priority_queue <int, vector<int>, greater<int> > pq;
   queue<int>pq;
   pq.push(index);
   vector<int>vis(n,0);
   while(!pq.empty())
   {
    int it=pq.front();
     cout<<it<<" ";
     vis[it]=1;
    pq.pop();
    if(bt[it]<=tq)
    {
        ct[it]=sum+bt[it];
        cout<<"ct:"<<ct[it]<<endl;
        sum+=bt[it];
        bt[it]=0;

    }
    else
    {
       
        bt[it]=bt[it]-tq;
        ct[it]=sum+tq;
        cout<<"ct:"<<ct[it]<<endl;

        sum+=tq;
    }
   
    for(int i=it;i<n;i++)
    {

        if(bt[i]!=0 && at[i]<=sum && i!=it &&vis[i]==0)
        {
            pq.push(i);
            vis[i]=1;
           // cout<<i<<" ";
        }
    }
    
    if(bt[it]!=0)
    {
        pq.push(it);
        
    }
   }
   //upto to time there are no new arrivals and but procwess is not
   for(int i=0;i<n;i++)
   {
    if(vis[i]==0)
    {
        ct[i]=sum+at[i];
        vis[i]=1;
        sum+=at[i];
    }
   }
 cout<<endl<<sum<<endl;
   int tat[n];
   double tatres=0;
   cout<<"cts:"<<" ";
   for(int i=0;i<n;i++)
   cout<<ct[i]<<" ";
   cout<<endl;
   cout<<"tat"<<endl;
   for(int i=0;i<n;i++)
   {
      tat[i]=ct[i]-at[i];
      tatres+=tat[i];
      cout<<tat[i]<<" ";
   }
   int wt[n];
   double wtres=0;
   cout<<endl<<"wt:"<<" ";
   for(int i=0;i<n;i++)
   {
      wt[i]=tat[i]-bt[i];
     wtres+=wt[i];
      cout<<wt[i]<<" ";
   } 
   cout<<endl<<"tat avg:"<<(tatres/n)<<endl<<"wt avg:"<<(wtres/n);
   
  

      
}