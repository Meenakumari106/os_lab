cout<<"enter frames:"<<" ";
    // int frames;
   
    // cin>>frames;