#include<bits/stdc++.h>
using namespace std;

int findmax(vector<int>&a,int n)
{
    int maxi=0,index=-1;
    for(int i=0;i<n;i++)
    {
        if(a[i]>=maxi)
        {
            maxi=a[i];
            index=i;
        }
    }
    return index;
}
void check(int key,int bl[],vector<int>&x,int n)
{
    for(int i=0;i<n;i++)
    {
        if(bl[i]>=key)
        {
            x[i]=bl[i];
        }
        else 
            x[i]=-1;
    }
}
int findmin(vector<int>&x,int n)
{
    int min=INT_MAX,index;
    for(int i=0;i<n;i++)
    {
        if(x[i]<min)
        {
            min=x[i];
            index=i;
        }
    }
    return index;
}

int main()
{
    cout<<"processor size:";
    int n;cin>>n;
    cout<<"block size:"<<endl;
    int s;cin>>s;
   int p[n],m[n],bl[s],a[s],am[s];
   for(int i=0;i<n;i++)
   {
     p[i]=i+1;
   }
   for(int i=0;i<n;i++) 
    cin>>m[i];
    for(int i=0;i<s;i++) 
    cin>>bl[i];
    vector<int>x(s,INT_MIN);
    for(int i=0;i<n;i++)
    {
        check(m[i],bl,x,s);
       
        int index=findmax(x,s);
        cout<<index<<endl;
       if(index!=-1)
       {
        a[index]=p[i];
        am[index]=m[i];
        bl[index]=0;
       }
    }
    for(int i=0;i<n;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<am[i]<<" ";
    }
}