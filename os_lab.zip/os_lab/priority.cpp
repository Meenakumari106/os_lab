#include<bits/stdc++.h>
using namespace std;
int minimum(int at[],int n)
{
    int min=at[0];
    int index;
     for(int i=0;i<n;i++)
     {
        if(at[i]<min)
        {
            min=at[i];
            index=i;
        }
     }
     return index;
}
int count(int x[],int n)
{
    int c=0;
    for(int i=0;i<n;i++)
    {
        if(x[i]!=INT_MAX)
          c++;
        
    }
    return c;
}
int main()
{
    int n;cin>>n;
    int at[n],bt[n],ct[n],pri[n];
    for(int i=0;i<n;i++)
     cin>>at[i];
     for(int i=0;i<n;i++)
     cin>>bt[i];
     for(int i=0;i<n;i++)
     cin>>pri[i];
    int index=minimum(at,n);
    //  priority_queue<int vector<int> greater<int> >pq;
    //  pq.push(index);
     
}