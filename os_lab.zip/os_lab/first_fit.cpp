#include<bits/stdc++.h>
using namespace std;
int main()
{
    int n;cin>>n;
   int p[n],m[n],bl[n],a[n],am[n];
   for(int i=0;i<n;i++)
   {
     p[i]=i+1;
   }
   for(int i=0;i<n;i++) 
    cin>>m[i];
    // for(int i=0;i<n;i++) 
    //   cin>>bl[i];
    // for(int i=0;i<n;i++) 
    //   cout<<p[i];
    // for(int i=0;i<n;i++) 
    //   cout<<bl[i];

    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            if(m[i]<=bl[j])
            {
                a[j]=p[i];
                am[j]=m[i];
                bl[j]=-1;
                break;
            }
        }
    }
    for(int i=0;i<n;i++)
    {
        cout<<a[i]<<" ";
    }
    cout<<endl;
    for(int i=0;i<n;i++)
    {
        cout<<am[i]<<" ";
    }


}