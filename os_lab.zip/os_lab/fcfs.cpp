#include<bits/stdc++.h>
using namespace std;
// void  process(int n,vector<pair<int,int>> a[])
// {
//     for(int i=1;i<=n;i++)
//     {
//         int at,bt;
//         cin>>at>>bt;
//         a[i].push_back({at,bt});
//     }
// }
int main()
{
    int n;
    //cin>>n;
    vector<pair<int,int>> a[3];
   a[0].push_back({1,2});//{make_pair({1,2}),make_pair({1,2}),make_pair({1,2})};
     a[1].push_back({1,2});
      a[0].push_back({3,4});
   //process(n,a);
   for(int i=0;i<3;i++){
    for(auto it:a[i]){
        cout<<it.first<<" "<<it.second<<" ";
    }cout<<endl;
   }
    priority_queue<pair<int,int>,vector<pair<int,int>>,greater<pair<int,int>>>pq;
    for(int i=0;i<n;i++)
    {
        for(auto it:a[i])
        {
        pq.push({a[it].first,a[it].second});
        }
    }
    while(!pq.empty())
    {
        cout<<pq.top().first<<" ";
        cout<<pq.top().second<<endl;
        pq.pop();
    }
    


}